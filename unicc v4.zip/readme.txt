THIS SCAMA IS MADE BY MANISH PAUL
CONTACT HIM FOR COPYRIGHT

-----------------------------------


BAKI KA TUM DEK LO 
CONTACT ME AT 
https://www.facebook.com/cyb3rd3vil
-----------------------------------

change your mail at index.php