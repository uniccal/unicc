
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" type="text/css" href="/css/main.css?v=1.6" />
<link rel="stylesheet" type="text/css" href="/ui/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="/ui/css/bootstrap-theme.min.css" />
<link rel="stylesheet" type="text/css" href="/ui/css/nstyle.min.css?v=1" />


<title>Shop - Signup Home</title>
</head>
<body class='login'>
    <div class='blocklogin'>
    <div class='titlelogin'>
        <img src='/img/logo.png'>

        <p>Sign-up</p>
    </div>
    <div class='loginform'>
        <div class='inputslogin'>
            <form class="form-signin form" autocomplete="off" id="signup-form" action="/" method="post" 
            name="signup">

            <div class="form-group"><div>
            	<input class="form-control" placeholder="Username" name="rusername" id="RegistrationForm_username" type="text" maxlength="20" size="6" required="required" /> 
            </div>
            </div>
                        <div class="form-group">
                            <div>
            		<input class="form-control" placeholder="Password" name="rpassword"  type="password" maxlength="40" required="required" size="8" />
                </div>
            </div>
                        <div class="form-group">
                            <div>
            			<input class="form-control" placeholder="Confirm Password" name="rcpassword"  type="password" required="required" size="8" />
                    </div>
                </div>
                                        <div class="form-group">
                                            <div>
            				<input  class="form-control" placeholder="Email" name="mail"  type="text" required="required" />
                        </div>
                    </div>
            <a href="/">
                <button type='button'>cancel</button>
            </a>
            <button type='submit' name="register">sign-up</button>
            </form>

        </div>
        <strong><div class="text-center" id="yw1"></div></strong>
    </div>
</div>
</body>
</html>