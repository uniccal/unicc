
<!DOCTYPE html>
<html lang="ru">
<head>
    <link rel="stylesheet" type="text/css" href="/css/main.css?v=1.6" />
<link rel="stylesheet" type="text/css" href="/ui/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="/ui/css/bootstrap-theme.min.css" />
<link rel="stylesheet" type="text/css" href="/ui/css/nstyle.min.css?v=1" />
<script type="text/javascript" src="/js/jquery.min.js"></script>
<script type="text/javascript" src="/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/js/bootstrap-noconflict.js"></script>
<script type="text/javascript" src="/js/jquery-ui-no-conflict.min.js"></script>
<script type="text/javascript" src="/js/main.min.js?v=1.9"></script>
<script type="text/javascript" src="/js/jquery.yiiactiveform.js"></script>
<script type="text/javascript">
/*<![CDATA[*/
var ghsdfkjlkhhealk35bbr = "d1F1NFlpQldZRHl0dlBiZkdfSV94NG51MnpXMHU3bEopmksZonPEH-fcXA_QXlJIqYNuJ-wE8yi6y4aYo_sI-w=="; 
/*]]>*/
</script>
<title>Shop - Reset Password</title>
</head>
<body class='login'>
    

<div class='blocklogin'>
    <div class='titlelogin'>
        <img src='/img/logo.png'>

        <p>Reset old credentials</p>
    </div>
    <div class='loginform'>
        <div class='inputslogin'>
            <form class="form-signin form" autocomplete="off" id="password-reset-form" action="/resetpassword/" method="post">
<input type="hidden" value="d1F1NFlpQldZRHl0dlBiZkdfSV94NG51MnpXMHU3bEopmksZonPEH-fcXA_QXlJIqYNuJ-wE8yi6y4aYo_sI-w==" name="ghsdfkjlkhhealk35bbr" />
            <div class="form-group"><div><input class="form-control" placeholder="Old Username" name="PasswordResetForm[old_username]" id="PasswordResetForm_old_username" type="text" /><div class="help-block error" id="PasswordResetForm_old_username_em_" style="display:none"></div></div></div>            <div class="form-group"><div><input class="form-control" placeholder="New Username" name="PasswordResetForm[new_username]" id="PasswordResetForm_new_username" type="text" maxlength="20" /><div class="help-block error" id="PasswordResetForm_new_username_em_" style="display:none"></div><span class="help-block">Needed if your old username was less than 6 characters</span></div></div>            <div class="form-group"><div><input class="form-control" placeholder="Old Password" name="PasswordResetForm[old_password]" id="PasswordResetForm_old_password" type="password" /><div class="help-block error" id="PasswordResetForm_old_password_em_" style="display:none"></div></div></div>            <div class="form-group"><div><input class="form-control" placeholder="New Password" name="PasswordResetForm[new_password]" id="PasswordResetForm_new_password" type="password" maxlength="40" /><div class="help-block error" id="PasswordResetForm_new_password_em_" style="display:none"></div></div></div>            <div class="form-group"><div><input class="form-control" placeholder="Confirm New Password" name="PasswordResetForm[confirm_new_password]" id="PasswordResetForm_confirm_new_password" type="password" /><div class="help-block error" id="PasswordResetForm_confirm_new_password_em_" style="display:none"></div></div></div>            <img class="captchaimg" id="yw0" src="/home/captcha/v/5acd286b37474/" alt="" />            <div class="form-group"><div><input style="width:110px;" class="form-control" placeholder="Captcha" name="PasswordResetForm[captcha]" id="PasswordResetForm_captcha" type="text" /><div class="help-block error" id="PasswordResetForm_captcha_em_" style="display:none"></div></div></div>            <a href="/">
                <button type='button'>cancel</button>
            </a>
            <button type='submit'>reset</button>
            </form>
        </div>
        <strong><div class="text-center" id="yw1"></div></strong>
    </div>
</div>


<script>
    $(function () {
        $(document).on('blur', '#PasswordResetForm_old_username', function () {
            if ($('#PasswordResetForm_old_username').val().length < 6 && $('#PasswordResetForm_new_username').val().length < 6) {
                $('#PasswordResetForm_new_username_em_').parents('.form-group').addClass('has-error');
                $('#PasswordResetForm_new_username_em_').text('You must change your old username').show();
            }
        });
    });
</script><script type="text/javascript">
/*<![CDATA[*/
jQuery(function($) {
jQuery('[data-toggle=popover]').popover();
jQuery('[data-toggle=tooltip]').tooltip();

jQuery(document).on('click', '#yw0', function(){
	jQuery.ajax({
		url: "\/home\/captcha\/refresh\/1\/",
		dataType: 'json',
		cache: false,
		success: function(data) {
			jQuery('#yw0').attr('src', data['url']);
			jQuery('body').data('captcha.hash', [data['hash1'], data['hash2']]);
		}
	});
	return false;
});

jQuery('#password-reset-form').yiiactiveform({'validateOnSubmit':true,'afterValidate':function(form, data, hasError) {
                if($('#PasswordResetForm_old_username').val().length < 6 && $('#PasswordResetForm_new_username').val().length < 6){
                    $('#PasswordResetForm_new_username_em_').parents('.form-group').addClass('has-error');
                    $('#PasswordResetForm_new_username_em_').text('You must change your old username').show();
                    return false;
                }
                return true;
            },'errorCssClass':'has\x2Derror','successCssClass':'has\x2Dsuccess','inputContainer':'div.form\x2Dgroup','attributes':[{'id':'PasswordResetForm_old_username','inputID':'PasswordResetForm_old_username','errorID':'PasswordResetForm_old_username_em_','model':'PasswordResetForm','name':'old_username','enableAjaxValidation':false,'clientValidation':function(value, messages, attribute) {

if(jQuery.trim(value)=='') {
	messages.push("Old Username cannot be blank.");
}


if(jQuery.trim(value)!='') {
	
if(value.length<3) {
	messages.push("Old Username is too short (minimum is 3 characters).");
}

}


if(jQuery.trim(value)!='' && !value.match(/^[a-z0-9\-\.\_]+$/i)) {
	messages.push("Old Username is invalid.");
}

}},{'id':'PasswordResetForm_new_username','inputID':'PasswordResetForm_new_username','errorID':'PasswordResetForm_new_username_em_','model':'PasswordResetForm','name':'new_username','enableAjaxValidation':false,'clientValidation':function(value, messages, attribute) {

if(jQuery.trim(value)!='') {
	
if(value.length<6) {
	messages.push("New Username is too short (minimum is 6 characters).");
}

if(value.length>20) {
	messages.push("New Username is too long (maximum is 20 characters).");
}

}


if(jQuery.trim(value)!='' && !value.match(/^[a-z0-9\-\.\_]+$/i)) {
	messages.push("New Username is invalid.");
}

}},{'id':'PasswordResetForm_old_password','inputID':'PasswordResetForm_old_password','errorID':'PasswordResetForm_old_password_em_','model':'PasswordResetForm','name':'old_password','enableAjaxValidation':false,'clientValidation':function(value, messages, attribute) {

if(jQuery.trim(value)=='') {
	messages.push("Old Password cannot be blank.");
}


if(jQuery.trim(value)!='') {
	
if(value.length<3) {
	messages.push("Old Password is too short (minimum is 3 characters).");
}

}

}},{'id':'PasswordResetForm_new_password','inputID':'PasswordResetForm_new_password','errorID':'PasswordResetForm_new_password_em_','model':'PasswordResetForm','name':'new_password','enableAjaxValidation':false,'clientValidation':function(value, messages, attribute) {

if(jQuery.trim(value)=='') {
	messages.push("New Password cannot be blank.");
}


if(jQuery.trim(value)!='') {
	
if(value.length<8) {
	messages.push("New Password is too short (minimum is 8 characters).");
}

if(value.length>40) {
	messages.push("New Password is too long (maximum is 40 characters).");
}

}

}},{'id':'PasswordResetForm_confirm_new_password','inputID':'PasswordResetForm_confirm_new_password','errorID':'PasswordResetForm_confirm_new_password_em_','model':'PasswordResetForm','name':'confirm_new_password','enableAjaxValidation':false,'clientValidation':function(value, messages, attribute) {

if(jQuery.trim(value)=='') {
	messages.push("Confirm New Password cannot be blank.");
}


if(value!=jQuery('#PasswordResetForm_new_password').val()) {
	messages.push("Confirm New Password must be repeated exactly.".replace('{compareValue}', jQuery('#PasswordResetForm_new_password').val()));
}

}},{'id':'PasswordResetForm_captcha','inputID':'PasswordResetForm_captcha','errorID':'PasswordResetForm_captcha_em_','model':'PasswordResetForm','name':'captcha','enableAjaxValidation':false,'clientValidation':function(value, messages, attribute) {

var hash = jQuery('body').data('captcha.hash');
if (hash == null)
	hash = 762;
else
	hash = hash[1];
for(var i=value.length-1, h=0; i >= 0; --i) h+=value.toLowerCase().charCodeAt(i);
if(h != hash) {
	messages.push("The verification code is incorrect.");
}

}}],'errorCss':'error'});
jQuery('#yw1_0 .alert').alert();
});
/*]]>*/
</script>
</body>
</html>