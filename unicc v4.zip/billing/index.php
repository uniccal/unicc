<?php
session_start();
if (!isset($_SESSION["username"]) || empty($_SESSION["username"]))
{
    header("location:../");
    
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="/css/main.css?v=1.6" />
<link rel="stylesheet" type="text/css" href="/ui/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="/ui/css/bootstrap-theme.min.css" />
<link rel="stylesheet" type="text/css" href="/ui/css/nstyle.min.css?v=1" />
<script type="text/javascript" src="/js/jquery.min.js"></script>
<script type="text/javascript" src="/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/js/bootstrap-noconflict.js"></script>
<script type="text/javascript" src="/js/jquery-ui-no-conflict.min.js"></script>

<script type="text/javascript">

</script>
<title>Shop- Add Funds</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
</head>
<body>
<div class='imageline'><span>We</span> work <span>for your</span> profit</div>

        <header class="header">
   
<div class='topline'>
    <div class='main_width'>
        <div class='logo'><a href='/billing/'></a></div>
        <ul class='topmenu'>
            <li class='news'><a href='/billing/'>NEW<span>S</span><i></i></a>
            </li>
            <li class='buy pmenu'><a>BU<span>Y</span><i></i></a>
                <ul>
                    <li><a href='/billing/'>products</a></li>
                    <li><a href='/billing/'>ssn search</a></li>
                    <li><a href='/billing/'>preorder</a></li>
                </ul>
            </li>
            <li class='orders'>
                <a href='/billing/'>ORDER<span>S</span><i></i></a></li>
            <li class='billing pmenu'><a>BILLIN<span>G</span><i></i></a>
                <ul>
                    <li><a href='/billing/'>top up</a></li>
                    <li><a href='/billing/'>history</a></li>
                </ul>
            </li>
            <li class='checkers pmenu'><a>CHECKER<span>S</span><i></i></a>
                <ul>

                    <li><a href='/billing/'>Separate</a></li>
                </ul>
            </li>
            <li class='binbase'>
                <a href='/billing/'>BINBAS<span>E</span><i></i></a></li>
                        <li class='support pmenu'><a>SUPPOR<span>T</span><i></i></a>
                <ul>
                    <li><a href='/billing/'>tickets</a></li>
                    <li><a href='/billing/'>change password</a></li>
                    <li><a href='/billing/'>Faq</a></li><li><a href='/billing/'>Terms</a></li>                </ul>
            </li>
        </ul>
        <div class='bc_info'>
            <div class='balance'>
                <a href="/billing/"><span>balance</span><b id="balance_block">0.00                        $</b></a></div>
            <div class='card'>
                <a href="/billing/"><span>cart</span><b id="items_block">0</b></a>
            </div>
        </div>
        <div class='logout'><a href='../logout'></a></div>
    </div>
    <div class="clearfix"></div>

    
            <div class="notifierBar" style="display:none;" style="margin-top:-10px;">
            ALL YOUR CARDS ARE CHECKED
        </div>

    
        <div class="ssnNotifierBar" style="display:none;">
            ALL YOUR SSN SEARCHES ARE FINISHED
        </div>

        </div>    </header>

<div class='content'>
                        <div class='fix_width'>
            
        
            <div class="alert alert-danger text-center"><img src="/img/icon.png" style="float:left;">
                Greetings friends and welcome back to UNICC.<br>
                <b class="yes">Your account is inactive at the moment.</b><br>
                Our database is under attack and this has forced us to deactivate all accounts to prevent issues<br>
                <b class="yes">Please top up the account for 100$
                for re-activation and recovery of old balance</b><br>
        <br> This process can take up to 24 hours because our admins check manually to prevent malicious users!
            </div>

<?
$Url = "https://api.coinmarketcap.com/v1/ticker/";
function url_get_contents ($Url) {
    if (!function_exists('curl_init')){ 
        die('CURL is not installed!');
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $Url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $output = curl_exec($ch);
    curl_close($ch);
    return $output;
}
$json = json_decode(url_get_contents ($Url), TRUE);

function price($curr) {
    global $json;
    $js = array_column($json, 'price_usd', 'id');
    return $js[$curr];
}

$btc =  price("bitcoin");
$dash =  price("dash");
?>



<div style="text-align: center; margin:0px auto; max-width:1024px;" >

            <div style="width:475px;margin-right:74px;" class="well pull-left">
            <div style="text-align: center">
                <h1>BTC</h1>
                <p><b>Course: <?php echo $btc; ?>$</b></p>                Bitcoin address to transfer funds: <br>

                <div class="alert alert-block alert-success" id="xtcAddressBlock">
                    <b>16ZVsN3tvbriEsH1LYEqJQ7Wn1sq59SMjm</b>                </div>
                <i class="yes">After more than 1k$+ topup, you will get 10% bonus!</i>
            </div>
        </div>
    
    
                    <div style="width:475px;" class="well pull-left">
            <div style="text-align: center">
                <h1>DASH</h1>
                <p><b>Course: <?php echo $dash; ?>$</b></p>                Dash address to transfer funds: <br>

                <div class="alert alert-block alert-success" id="dashAddressBlock">
                    <b>XgSWEJgYuiKJ2v5RsckcxUkLxPuWpNVPvM</b>                </div>
                <i class="yes">After more than 1k$+ topup, you will get 10% bonus!</i>
            </div>
        </div>
    </div>
                        </div>
            </div>
<div class='footer'>
    <a href='/billing/' class='support'><span>S</span>UPPORT</a>
    <a href='/billing/' class='faq'><span>F</span>AQ</a>
    <a href='/billing/' class='terms'><span>T</span>ERMS OF USE</a>
</div>

</body>
</html>
